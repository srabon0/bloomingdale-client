import React from 'react';

const Checkout = () => {
    return (
        <div style={{"height": "75vh"}}>
            <div className="card w-96 mx-auto py-8 my-8 bg-neutral text-neutral-content">
                <div className="card-body items-center text-center">
                    <h2 className="card-title">Thank for the proceed!</h2>
                    <p>See you soon.</p>
                    <div className="card-actions justify-end">

                    </div>
                </div>
            </div>
        </div>
    );
};

export default Checkout;