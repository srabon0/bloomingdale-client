import React from 'react';
import notfound from '../../images/404.jpg';
const NotFound = () => {
    return (
        <div>
           <img src="https://img.freepik.com/free-vector/error-404-concept-landing-page_52683-12757.jpg?t=st=1650302151~exp=1650302751~hmac=b2aa5a51b4eb2e5c0967b73c9a3c1feeafea082c660bdae1d21d0d0e986d2057&w=740"className="obejct-contain w-5/6 mx-auto" />
        </div>
    );
};

export default NotFound;