import * as React from "react";
import { Routes, Route } from "react-router-dom";
import "./App.css";

import Home from './components/Home/Home';
import About from './components/About/About';
import Dashboard from './components/Dashboard/Dashboard';
import Review from './components/Review/Review';
import Contact from './components/Contact/Contact';
import Navigation from "./components/Navigation/Navigation";
import Notfound from "./components/Notfound/Notfound";
import Blogs from "./components/Blogs/Blogs";
import Footer from "./components/Footer/Footer";




function App() {
  return (
    <div className="App">
     <Navigation></Navigation>
      <Routes>
      <Route path="/" element={<Home></Home>} ></Route>
      <Route path="/home" element={<Home></Home>} ></Route>
      <Route path="/about" element={<About></About>} ></Route>
      <Route path="/review" element={<Review></Review>} ></Route>
      <Route path="/dashboard" element={<Dashboard></Dashboard>} ></Route>
      <Route path="/contact" element={<Contact></Contact>} ></Route>
      <Route path="/blogs" element={<Blogs></Blogs>} ></Route>
      <Route path="*" element={<Notfound></Notfound>} ></Route>
      </Routes>
     <Footer></Footer>
     
    </div>
  );
}
export default App;