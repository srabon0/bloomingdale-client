import React from 'react';
import { Card } from 'react-bootstrap';
import Rating from 'react-rating';
import { faStar } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const User = (props) => {
    const {name,rating,picture,text,email} = props.review
    return (
      <div className='col'>
        <Card style={{"width":"18rem"}}>
        <Card.Img variant="top" className="rounded" style={{"width":"50px", "margin":"5px",}} src={picture} />
        <Card.Title style={{"font-size":"20px"}} >{name}</Card.Title>
        <Card.Body>
   
          <Card.Text style={{"font-size":"16px"}} >Review : <Rating
          initialRating={rating}
          emptySymbol={<FontAwesomeIcon icon={faStar} />}
          fullSymbol={<FontAwesomeIcon style={{color: 'goldenrod'}} icon={faStar} />}
          readonly
      ></Rating>  </Card.Text>
          <Card.Text>
            {text}
          </Card.Text>

          <Card.Text>
            <small className='text-muted '> Email: {email}</small>
          </Card.Text>
        
        </Card.Body>
      </Card>


      </div>

    );
};

export default User;