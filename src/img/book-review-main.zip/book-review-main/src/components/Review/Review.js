import React from 'react';
import useReviews from '../../Hooks/useReviews';
import User from '../User/User';
import './Review.css';

const Review = () => {
    const[reviews,setReviews] = useReviews();
    return (
       <div className='container g-4' >
           <h1 className='fs-1 fw-bold text-success mt-5 border border-2 border-rounded-3'>All customer review</h1>
           

        <div className='container my-5'>
        <div className='row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4' >
            {reviews.map(review=><User key={review._id}  review={review}></User>)}
            </div>
          
          
           
        </div>
       

       </div>
    );
};

export default Review;