import React from 'react';
import NotFound from '../../assets/img/detective.webp'

const Notfound = () => {
    return (
        <div className='container text-center '>
            <img style={{ "width":"75%" }} src={NotFound} alt="not found" />
            
        </div>
    );
};

export default Notfound;