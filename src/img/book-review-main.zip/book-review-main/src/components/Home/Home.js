import React from 'react';
import useReviews from '../../Hooks/useReviews';
import User from '../User/User';
import './Home.css'

import { useNavigate } from 'react-router';

const Home = () => {
    const [reviews,setReviews] = useReviews()
    const navigate = useNavigate();
    return (
        <>
        <div className='container mt-5 ' >
            <div className="row">
                <div className="col-lg-6 col-10 mx-auto py-5">
                    <h1 className='fs-1 fw-bold text-dark' > Find your Favourite book. <br /> <span className="text-danger">Buy this Awesome detective Thriller.</span> </h1>
                    <button className='my-5 px-5 fs-4 btn btn-outline-dark'>Buy Now</button>
                   
                </div>
                <div className="col-lg-6 col-10 mx-auto">
                    <img className='img-fluid shadow-lg p-3 mb-5 bg-body rounded' src='https://almabooks.com/wp-content/uploads/2016/10/adventures-of-Sherlock-Holmes.jpg' alt="" />
                </div>
            </div>
           
        </div>
        <div className='container mt-5'>
            <h1 className='text-decoration-underline text-danger fs-2 fw-bold mb-5'> Our customer says </h1>
                    <div className='row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4' >
                    
                    {reviews.slice(0,3).map(review=><User key={review._id}  review={review}></User>)}
                    
                </div>
                <button className='my-5 btn btn-outline-warning fs-3 px-5 fw-bold' onClick={() => navigate("/review")} >See All Review</button>
        </div>
        
        </>
        
    );
};

export default Home;