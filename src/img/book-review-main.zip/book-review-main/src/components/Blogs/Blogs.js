import React from 'react';

const Blogs = () => {
    return (
        <div className='container my-5'>
            <div className='row'>
                <div className='col-12 col-lg-10 mx-auto'>
                        <h1>What is CONTEXT API?</h1>
                        <p>
                            Passing data from one components to another componets really get messy when there is a lot of complex componet is nested inside another component. Then the CONTEXT API showed up!!!
                            sending data as props over and over again can be very confusing also slow down the process. So Context api solves this problem for the developers.
                            <strong>
                            The Context API can be used to share data with multiple components, without having to pass data through props manually. The context api use a hook called  <i>  useContext() </i>
                            The context api solves the props-drilling problem.</strong>
                        </p>
                </div>
                <div className='col-12 col-lg-10 mx-auto'>
                        <h1>What is SEMANTIC TAG?</h1>
                        <p>
                            As the Internet is changing day by day it is adopted by a lot of people these days. The html was created long ago its one of the oldest documents in the internet it needed to be changed because a lot of people are interacting with it regularly.
                            Semantic tags are created to make html more understandble for both programmers and non programmers .
                            These tags are easy to understand and easier to read the html documents which means a better experience to an user.
                            Some html tags are : header, section, article etc.
                        </p>
                </div>
                <div className='col-12 col-lg-10 mx-auto'>
                        <h1>What is Block element and Inline element?</h1>
                        <p>
                           <strong>Block:</strong> a block level element always takes the full width of the viewport available. it always start a new line documents and browser sometimes add extra margin or padding to it.
                           Block level elemetns are: div , h1, article , section etc.
                        </p>
                            <br />
                            <br />
                        <p>
                           <strong>Inline:</strong> an inline element takes the width necessary nothing much. It do not start a new line in the html documents.
                           Inline level elemetns are: span , a, small etc.
                        </p>
                </div>
            </div>
            
        </div>
    );
};

export default Blogs;