import './About.css';
const About = () =>
{

        const technologies = [
            { id: 1, title: "Font Awesome", url:"https://fontawesome.com/" },
            { id: 2, title: "React", url:"https://reactjs.org/" },
            { id: 3, title: "Bootstrap 5", url:"hhttps://getbootstrap.com/" },
            { id: 4, title: "React Router Dom", url:"https://reactrouterdotcom.fly.dev/docs/en/v6" },
    
        ]
  
  //console.log(show, location)
  return <>
    <section className="text-secondary my-5 aboutpage">
      <div className="container">
        <div className="row">
          <div className="col-md-7">
            <h2>Project Details</h2>
            <p>In this assignment, I tried to build a Book Review Site.<br /> Well, I know that it looks like nonprofessional<br /></p>
            <p>I used Fake data. I got data from there and used it with JSON-Server. <br /> Why did I do this? <br /> I just wanted to try JSON-Server and Created fake API.</p>
            <p>You can see all review details.</p>
          </div>
          <div className="col-md-5 drop-cap-text">
            <h2>Technologies That I Used</h2>
            <div className="list-group">
              {technologies.map(data =>
              
                <a href={data.url} key={data.id} target="_blank" rel="noopener   noreferrer" className="list-group-item list-group-item-action list-group-item-light">
                  {data.title}
                </a>)
              }
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
}
export default About


  