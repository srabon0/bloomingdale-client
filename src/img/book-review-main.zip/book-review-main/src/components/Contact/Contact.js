import React from 'react';
import './contact.css';
import { Button, Form } from 'react-bootstrap';

const Contact = () => {
    return (
        <div className='container mx-auto contactpage mt-5'>
            
            <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label className='fs-3'>Email</Form.Label>
            <Form.Control type="email" placeholder="name@example.com" />
        </Form.Group>
        <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
            <Form.Label className='fs-3'>Message</Form.Label>
            <Form.Control as="textarea" rows={3} />
        </Form.Group>
        <Button variant="primary" type="submit">
            Submit
        </Button>
        </Form>
        </div>
    );
};

export default Contact;