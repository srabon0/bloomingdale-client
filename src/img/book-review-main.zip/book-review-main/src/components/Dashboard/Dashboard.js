import React from 'react';
import Revenueline from '../Revenueline/Revenueline';

const Dashboard = () => {
    return (
        <div className='container'>
            <Revenueline></Revenueline>
        </div>
    );
};

export default Dashboard;