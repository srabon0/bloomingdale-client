# Getting Started with Bookish-People

This project is live [Bookish People](https://storied-sprinkles-30c54f.netlify.app/).

## Main Feature USED IN THE PROJECT

This project is created using these tools and technologies:

### React-Bootstrap

react bootrap is very easy to use.

### React Router 

React Router is a fully-featured client and server-side routing library for React, a JavaScript library for building user interfaces. React Router runs anywhere React runs; on the web, on the server with node.js, and on React Native.

### ReChart

we can use neat data visualization methods that leverage the brain’s ability to identify and process data in a visual way. To help you get started and easily add beautiful data visualization to your favorite application, here are some of the best Javascript data visualization libraries around in 2018 (unranked). Feel free to comment and add your own suggestions and insights!
